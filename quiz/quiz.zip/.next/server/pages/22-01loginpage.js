"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/22-01loginpage";
exports.ids = ["pages/22-01loginpage"];
exports.modules = {

/***/ "./pages/22-01loginpage/index.tsx":
/*!****************************************!*\
  !*** ./pages/22-01loginpage/index.tsx ***!
  \****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ LoginPage)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @apollo/client */ \"@apollo/client\");\n/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_apollo_client__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/router */ \"next/router\");\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);\n/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! recoil */ \"recoil\");\n/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(recoil__WEBPACK_IMPORTED_MODULE_4__);\n/* harmony import */ var _src_commons_store__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../src/commons/store */ \"./src/commons/store/index.ts\");\n\n\n\n\n\n\nconst LOGIN_USER = _apollo_client__WEBPACK_IMPORTED_MODULE_1__.gql`\n    mutation loginUser($email: String!, $password: String!) {\n        loginUser(email: $email, password: $password) {\n            accessToken\n        }\n    }\n`;\nfunction LoginPage() {\n    const [, setAccessToken] = (0,recoil__WEBPACK_IMPORTED_MODULE_4__.useRecoilState)(_src_commons_store__WEBPACK_IMPORTED_MODULE_5__.accessTokenState);\n    const { 0: email , 1: setEmail  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(\"\");\n    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();\n    const { 0: password , 1: setPassword  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(\"\");\n    const [loginUser] = (0,_apollo_client__WEBPACK_IMPORTED_MODULE_1__.useMutation)(LOGIN_USER);\n    const onChangeEmail = (event)=>{\n        setEmail(event.target.value);\n    };\n    const onChangePassword = (event)=>{\n        setPassword(event.target.value);\n    };\n    const onClickLogin = async ()=>{\n        const result = await loginUser({\n            variables: {\n                email,\n                password\n            }\n        });\n        const accessToken = result.data.loginUser.accessToken;\n        setAccessToken(accessToken);\n        console.log(accessToken);\n        alert(\"로그인에 성공하였습니다!!.\");\n        router.push(\"22-02-loginsuccess\");\n    };\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        children: [\n            \"이메일:\",\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"input\", {\n                type: \"text\",\n                onChange: onChangeEmail\n            }, void 0, false, {\n                fileName: \"C:\\\\Users\\\\코드캠프\\\\Desktop\\\\codecamp fe-06\\\\quiz\\\\pages\\\\22-01loginpage\\\\index.tsx\",\n                lineNumber: 45,\n                columnNumber: 13\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"br\", {}, void 0, false, {\n                fileName: \"C:\\\\Users\\\\코드캠프\\\\Desktop\\\\codecamp fe-06\\\\quiz\\\\pages\\\\22-01loginpage\\\\index.tsx\",\n                lineNumber: 46,\n                columnNumber: 13\n            }, this),\n            \"Password:\",\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"input\", {\n                type: \"password\",\n                onChange: onChangePassword\n            }, void 0, false, {\n                fileName: \"C:\\\\Users\\\\코드캠프\\\\Desktop\\\\codecamp fe-06\\\\quiz\\\\pages\\\\22-01loginpage\\\\index.tsx\",\n                lineNumber: 48,\n                columnNumber: 13\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"br\", {}, void 0, false, {\n                fileName: \"C:\\\\Users\\\\코드캠프\\\\Desktop\\\\codecamp fe-06\\\\quiz\\\\pages\\\\22-01loginpage\\\\index.tsx\",\n                lineNumber: 49,\n                columnNumber: 13\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"button\", {\n                onClick: onClickLogin,\n                children: \"로그인\"\n            }, void 0, false, {\n                fileName: \"C:\\\\Users\\\\코드캠프\\\\Desktop\\\\codecamp fe-06\\\\quiz\\\\pages\\\\22-01loginpage\\\\index.tsx\",\n                lineNumber: 50,\n                columnNumber: 13\n            }, this)\n        ]\n    }, void 0, true, {\n        fileName: \"C:\\\\Users\\\\코드캠프\\\\Desktop\\\\codecamp fe-06\\\\quiz\\\\pages\\\\22-01loginpage\\\\index.tsx\",\n        lineNumber: 43,\n        columnNumber: 9\n    }, this));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy8yMi0wMWxvZ2lucGFnZS9pbmRleC50c3guanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7OztBQUFpRDtBQUNWO0FBQ1A7QUFDTztBQUNtQjtBQUUxRCxLQUFLLENBQUNNLFVBQVUsR0FBR0wsK0NBQUcsQ0FBQzs7Ozs7O0FBTXZCO0FBRWUsUUFBUSxDQUFDTSxTQUFTLEdBQUcsQ0FBQztJQUNqQyxLQUFLLElBQUlDLGNBQWMsSUFBSUosc0RBQWMsQ0FBQ0MsZ0VBQWdCO0lBQzFELEtBQUssTUFBRUksS0FBSyxNQUFFQyxRQUFRLE1BQUlQLCtDQUFRLENBQUMsQ0FBRTtJQUNyQyxLQUFLLENBQUNRLE1BQU0sR0FBR1Qsc0RBQVM7SUFDeEIsS0FBSyxNQUFFVSxRQUFRLE1BQUVDLFdBQVcsTUFBSVYsK0NBQVEsQ0FBQyxDQUFFO0lBQzNDLEtBQUssRUFBRVcsU0FBUyxJQUFJZCwyREFBVyxDQUFDTSxVQUFVO0lBRTFDLEtBQUssQ0FBQ1MsYUFBYSxJQUFJQyxLQUFLLEdBQUssQ0FBQztRQUM5Qk4sUUFBUSxDQUFDTSxLQUFLLENBQUNDLE1BQU0sQ0FBQ0MsS0FBSztJQUMvQixDQUFDO0lBQ0QsS0FBSyxDQUFDQyxnQkFBZ0IsSUFBSUgsS0FBSyxHQUFLLENBQUM7UUFDakNILFdBQVcsQ0FBQ0csS0FBSyxDQUFDQyxNQUFNLENBQUNDLEtBQUs7SUFDbEMsQ0FBQztJQUNELEtBQUssQ0FBQ0UsWUFBWSxhQUFlLENBQUM7UUFDOUIsS0FBSyxDQUFDQyxNQUFNLEdBQUcsS0FBSyxDQUFDUCxTQUFTLENBQUMsQ0FBQztZQUM1QlEsU0FBUyxFQUFFLENBQUM7Z0JBQ1JiLEtBQUs7Z0JBQ0xHLFFBQVE7WUFDWixDQUFDO1FBQ0wsQ0FBQztRQUNELEtBQUssQ0FBQ1csV0FBVyxHQUFHRixNQUFNLENBQUNHLElBQUksQ0FBQ1YsU0FBUyxDQUFDUyxXQUFXO1FBQ3JEZixjQUFjLENBQUNlLFdBQVc7UUFDMUJFLE9BQU8sQ0FBQ0MsR0FBRyxDQUFDSCxXQUFXO1FBQ3ZCSSxLQUFLLENBQUMsQ0FBaUI7UUFDRGhCLE1BQWhCLENBQUNpQixJQUFJLENBQUMsQ0FBb0I7SUFDcEMsQ0FBQztJQUVELE1BQU0sNkVBQ0RDLENBQUc7O1lBQUMsQ0FFRDt3RkFBQ0MsQ0FBSztnQkFBQ0MsSUFBSSxFQUFDLENBQU07Z0JBQUNDLFFBQVEsRUFBRWpCLGFBQWE7Ozs7Ozt3RkFDekNrQixDQUFFOzs7OztZQUFHLENBRU47d0ZBQUNILENBQUs7Z0JBQUNDLElBQUksRUFBQyxDQUFVO2dCQUFDQyxRQUFRLEVBQUViLGdCQUFnQjs7Ozs7O3dGQUNoRGMsQ0FBRTs7Ozs7d0ZBQ0ZDLENBQU07Z0JBQUNDLE9BQU8sRUFBRWYsWUFBWTswQkFBRSxDQUFHOzs7Ozs7Ozs7Ozs7QUFHOUMsQ0FBQyIsInNvdXJjZXMiOlsid2VicGFjazovL2NsYXNzLy4vcGFnZXMvMjItMDFsb2dpbnBhZ2UvaW5kZXgudHN4P2YyZmUiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlTXV0YXRpb24sIGdxbCB9IGZyb20gXCJAYXBvbGxvL2NsaWVudFwiO1xyXG5pbXBvcnQgeyB1c2VSb3V0ZXIgfSBmcm9tIFwibmV4dC9yb3V0ZXJcIjtcclxuaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgdXNlUmVjb2lsU3RhdGUgfSBmcm9tIFwicmVjb2lsXCI7XHJcbmltcG9ydCB7IGFjY2Vzc1Rva2VuU3RhdGUgfSBmcm9tIFwiLi4vLi4vc3JjL2NvbW1vbnMvc3RvcmVcIjtcclxuXHJcbmNvbnN0IExPR0lOX1VTRVIgPSBncWxgXHJcbiAgICBtdXRhdGlvbiBsb2dpblVzZXIoJGVtYWlsOiBTdHJpbmchLCAkcGFzc3dvcmQ6IFN0cmluZyEpIHtcclxuICAgICAgICBsb2dpblVzZXIoZW1haWw6ICRlbWFpbCwgcGFzc3dvcmQ6ICRwYXNzd29yZCkge1xyXG4gICAgICAgICAgICBhY2Nlc3NUb2tlblxyXG4gICAgICAgIH1cclxuICAgIH1cclxuYDtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIExvZ2luUGFnZSgpIHtcclxuICAgIGNvbnN0IFssIHNldEFjY2Vzc1Rva2VuXSA9IHVzZVJlY29pbFN0YXRlKGFjY2Vzc1Rva2VuU3RhdGUpO1xyXG4gICAgY29uc3QgW2VtYWlsLCBzZXRFbWFpbF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICAgIGNvbnN0IHJvdXRlciA9IHVzZVJvdXRlcigpO1xyXG4gICAgY29uc3QgW3Bhc3N3b3JkLCBzZXRQYXNzd29yZF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICAgIGNvbnN0IFtsb2dpblVzZXJdID0gdXNlTXV0YXRpb24oTE9HSU5fVVNFUik7XHJcblxyXG4gICAgY29uc3Qgb25DaGFuZ2VFbWFpbCA9IChldmVudCkgPT4ge1xyXG4gICAgICAgIHNldEVtYWlsKGV2ZW50LnRhcmdldC52YWx1ZSk7XHJcbiAgICB9O1xyXG4gICAgY29uc3Qgb25DaGFuZ2VQYXNzd29yZCA9IChldmVudCkgPT4ge1xyXG4gICAgICAgIHNldFBhc3N3b3JkKGV2ZW50LnRhcmdldC52YWx1ZSk7XHJcbiAgICB9O1xyXG4gICAgY29uc3Qgb25DbGlja0xvZ2luID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IGxvZ2luVXNlcih7XHJcbiAgICAgICAgICAgIHZhcmlhYmxlczoge1xyXG4gICAgICAgICAgICAgICAgZW1haWwsXHJcbiAgICAgICAgICAgICAgICBwYXNzd29yZCxcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICB9KTtcclxuICAgICAgICBjb25zdCBhY2Nlc3NUb2tlbiA9IHJlc3VsdC5kYXRhLmxvZ2luVXNlci5hY2Nlc3NUb2tlbjtcclxuICAgICAgICBzZXRBY2Nlc3NUb2tlbihhY2Nlc3NUb2tlbik7XHJcbiAgICAgICAgY29uc29sZS5sb2coYWNjZXNzVG9rZW4pO1xyXG4gICAgICAgIGFsZXJ0KFwi66Gc6re47J247JeQIOyEseqzte2VmOyYgOyKteuLiOuLpCEhLlwiKTtcclxuICAgICAgICByb3V0ZXIucHVzaChcIjIyLTAyLWxvZ2luc3VjY2Vzc1wiKTtcclxuICAgIH07XHJcblxyXG4gICAgcmV0dXJuIChcclxuICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICDsnbTrqZTsnbw6XHJcbiAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwidGV4dFwiIG9uQ2hhbmdlPXtvbkNoYW5nZUVtYWlsfSAvPlxyXG4gICAgICAgICAgICA8YnIgLz5cclxuICAgICAgICAgICAgUGFzc3dvcmQ6XHJcbiAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwicGFzc3dvcmRcIiBvbkNoYW5nZT17b25DaGFuZ2VQYXNzd29yZH0gLz5cclxuICAgICAgICAgICAgPGJyIC8+XHJcbiAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17b25DbGlja0xvZ2lufT7roZzqt7jsnbg8L2J1dHRvbj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICk7XHJcbn1cclxuIl0sIm5hbWVzIjpbInVzZU11dGF0aW9uIiwiZ3FsIiwidXNlUm91dGVyIiwidXNlU3RhdGUiLCJ1c2VSZWNvaWxTdGF0ZSIsImFjY2Vzc1Rva2VuU3RhdGUiLCJMT0dJTl9VU0VSIiwiTG9naW5QYWdlIiwic2V0QWNjZXNzVG9rZW4iLCJlbWFpbCIsInNldEVtYWlsIiwicm91dGVyIiwicGFzc3dvcmQiLCJzZXRQYXNzd29yZCIsImxvZ2luVXNlciIsIm9uQ2hhbmdlRW1haWwiLCJldmVudCIsInRhcmdldCIsInZhbHVlIiwib25DaGFuZ2VQYXNzd29yZCIsIm9uQ2xpY2tMb2dpbiIsInJlc3VsdCIsInZhcmlhYmxlcyIsImFjY2Vzc1Rva2VuIiwiZGF0YSIsImNvbnNvbGUiLCJsb2ciLCJhbGVydCIsInB1c2giLCJkaXYiLCJpbnB1dCIsInR5cGUiLCJvbkNoYW5nZSIsImJyIiwiYnV0dG9uIiwib25DbGljayJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./pages/22-01loginpage/index.tsx\n");

/***/ }),

/***/ "./src/commons/store/index.ts":
/*!************************************!*\
  !*** ./src/commons/store/index.ts ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"isEditState\": () => (/* binding */ isEditState),\n/* harmony export */   \"accessTokenState\": () => (/* binding */ accessTokenState)\n/* harmony export */ });\n/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! recoil */ \"recoil\");\n/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(recoil__WEBPACK_IMPORTED_MODULE_0__);\n\nconst isEditState = (0,recoil__WEBPACK_IMPORTED_MODULE_0__.atom)({\n    key: \"isEditState\",\n    default: false\n});\nconst accessTokenState = (0,recoil__WEBPACK_IMPORTED_MODULE_0__.atom)({\n    key: \"accessTokenState\",\n    default: \"\"\n}); // 글로벌 스테이트 isEditState 로 만든다 아톰으로\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvY29tbW9ucy9zdG9yZS9pbmRleC50cy5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7O0FBQTZCO0FBRXRCLEtBQUssQ0FBQ0MsV0FBVyxHQUFHRCw0Q0FBSSxDQUFDLENBQUM7SUFDN0JFLEdBQUcsRUFBRSxDQUFhO0lBQ2xCQyxPQUFPLEVBQUUsS0FBSztBQUNsQixDQUFDO0FBRU0sS0FBSyxDQUFDQyxnQkFBZ0IsR0FBR0osNENBQUksQ0FBQyxDQUFDO0lBQ2xDRSxHQUFHLEVBQUUsQ0FBa0I7SUFDdkJDLE9BQU8sRUFBRSxDQUFFO0FBQ2YsQ0FBQyxFQUNELENBQWtDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vY2xhc3MvLi9zcmMvY29tbW9ucy9zdG9yZS9pbmRleC50cz8zY2JmIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGF0b20gfSBmcm9tIFwicmVjb2lsXCI7XHJcblxyXG5leHBvcnQgY29uc3QgaXNFZGl0U3RhdGUgPSBhdG9tKHtcclxuICAgIGtleTogXCJpc0VkaXRTdGF0ZVwiLFxyXG4gICAgZGVmYXVsdDogZmFsc2UsXHJcbn0pO1xyXG5cclxuZXhwb3J0IGNvbnN0IGFjY2Vzc1Rva2VuU3RhdGUgPSBhdG9tKHtcclxuICAgIGtleTogXCJhY2Nlc3NUb2tlblN0YXRlXCIsXHJcbiAgICBkZWZhdWx0OiBcIlwiLFxyXG59KTtcclxuLy8g6riA66Gc67KMIOyKpO2FjOydtO2KuCBpc0VkaXRTdGF0ZSDroZwg66eM65Og64ukIOyVhO2GsOycvOuhnFxyXG4iXSwibmFtZXMiOlsiYXRvbSIsImlzRWRpdFN0YXRlIiwia2V5IiwiZGVmYXVsdCIsImFjY2Vzc1Rva2VuU3RhdGUiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./src/commons/store/index.ts\n");

/***/ }),

/***/ "@apollo/client":
/*!*********************************!*\
  !*** external "@apollo/client" ***!
  \*********************************/
/***/ ((module) => {

module.exports = require("@apollo/client");

/***/ }),

/***/ "next/router":
/*!******************************!*\
  !*** external "next/router" ***!
  \******************************/
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ }),

/***/ "recoil":
/*!*************************!*\
  !*** external "recoil" ***!
  \*************************/
/***/ ((module) => {

module.exports = require("recoil");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/22-01loginpage/index.tsx"));
module.exports = __webpack_exports__;

})();