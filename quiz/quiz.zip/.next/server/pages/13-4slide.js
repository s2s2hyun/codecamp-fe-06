"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/13-4slide";
exports.ids = ["pages/13-4slide"];
exports.modules = {

/***/ "./pages/13-4slide/index.tsx":
/*!***********************************!*\
  !*** ./pages/13-4slide/index.tsx ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ SimpleSlider)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-slick */ \"react-slick\");\n/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_slick__WEBPACK_IMPORTED_MODULE_2__);\n\n\n\nclass SimpleSlider extends react__WEBPACK_IMPORTED_MODULE_1__.Component {\n    render() {\n        const settings = {\n            dots: true,\n            infinite: true,\n            speed: 500,\n            slidesToShow: 1,\n            slidesToScroll: 1\n        };\n        return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n            children: [\n                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"h2\", {\n                    children: \" src\"\n                }, void 0, false, {\n                    fileName: \"C:\\\\Users\\\\코드캠프\\\\Desktop\\\\codecamp fe-06\\\\quiz\\\\pages\\\\13-4slide\\\\index.tsx\",\n                    lineNumber: 15,\n                    columnNumber: 17\n                }, this),\n                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((react_slick__WEBPACK_IMPORTED_MODULE_2___default()), {\n                    ...settings,\n                    children: [\n                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                            children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"h3\", {\n                                children: \"1\"\n                            }, void 0, false, {\n                                fileName: \"C:\\\\Users\\\\코드캠프\\\\Desktop\\\\codecamp fe-06\\\\quiz\\\\pages\\\\13-4slide\\\\index.tsx\",\n                                lineNumber: 18,\n                                columnNumber: 25\n                            }, this)\n                        }, void 0, false, {\n                            fileName: \"C:\\\\Users\\\\코드캠프\\\\Desktop\\\\codecamp fe-06\\\\quiz\\\\pages\\\\13-4slide\\\\index.tsx\",\n                            lineNumber: 17,\n                            columnNumber: 21\n                        }, this),\n                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                            children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"h3\", {\n                                children: \"2\"\n                            }, void 0, false, {\n                                fileName: \"C:\\\\Users\\\\코드캠프\\\\Desktop\\\\codecamp fe-06\\\\quiz\\\\pages\\\\13-4slide\\\\index.tsx\",\n                                lineNumber: 21,\n                                columnNumber: 25\n                            }, this)\n                        }, void 0, false, {\n                            fileName: \"C:\\\\Users\\\\코드캠프\\\\Desktop\\\\codecamp fe-06\\\\quiz\\\\pages\\\\13-4slide\\\\index.tsx\",\n                            lineNumber: 20,\n                            columnNumber: 21\n                        }, this),\n                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                            children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"h3\", {\n                                children: \"3\"\n                            }, void 0, false, {\n                                fileName: \"C:\\\\Users\\\\코드캠프\\\\Desktop\\\\codecamp fe-06\\\\quiz\\\\pages\\\\13-4slide\\\\index.tsx\",\n                                lineNumber: 24,\n                                columnNumber: 25\n                            }, this)\n                        }, void 0, false, {\n                            fileName: \"C:\\\\Users\\\\코드캠프\\\\Desktop\\\\codecamp fe-06\\\\quiz\\\\pages\\\\13-4slide\\\\index.tsx\",\n                            lineNumber: 23,\n                            columnNumber: 21\n                        }, this),\n                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                            children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"h3\", {\n                                children: \"4\"\n                            }, void 0, false, {\n                                fileName: \"C:\\\\Users\\\\코드캠프\\\\Desktop\\\\codecamp fe-06\\\\quiz\\\\pages\\\\13-4slide\\\\index.tsx\",\n                                lineNumber: 27,\n                                columnNumber: 25\n                            }, this)\n                        }, void 0, false, {\n                            fileName: \"C:\\\\Users\\\\코드캠프\\\\Desktop\\\\codecamp fe-06\\\\quiz\\\\pages\\\\13-4slide\\\\index.tsx\",\n                            lineNumber: 26,\n                            columnNumber: 21\n                        }, this),\n                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                            children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"h3\", {\n                                children: \"5\"\n                            }, void 0, false, {\n                                fileName: \"C:\\\\Users\\\\코드캠프\\\\Desktop\\\\codecamp fe-06\\\\quiz\\\\pages\\\\13-4slide\\\\index.tsx\",\n                                lineNumber: 30,\n                                columnNumber: 25\n                            }, this)\n                        }, void 0, false, {\n                            fileName: \"C:\\\\Users\\\\코드캠프\\\\Desktop\\\\codecamp fe-06\\\\quiz\\\\pages\\\\13-4slide\\\\index.tsx\",\n                            lineNumber: 29,\n                            columnNumber: 21\n                        }, this),\n                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                            children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"h3\", {\n                                children: \"6\"\n                            }, void 0, false, {\n                                fileName: \"C:\\\\Users\\\\코드캠프\\\\Desktop\\\\codecamp fe-06\\\\quiz\\\\pages\\\\13-4slide\\\\index.tsx\",\n                                lineNumber: 33,\n                                columnNumber: 25\n                            }, this)\n                        }, void 0, false, {\n                            fileName: \"C:\\\\Users\\\\코드캠프\\\\Desktop\\\\codecamp fe-06\\\\quiz\\\\pages\\\\13-4slide\\\\index.tsx\",\n                            lineNumber: 32,\n                            columnNumber: 21\n                        }, this)\n                    ]\n                }, void 0, true, {\n                    fileName: \"C:\\\\Users\\\\코드캠프\\\\Desktop\\\\codecamp fe-06\\\\quiz\\\\pages\\\\13-4slide\\\\index.tsx\",\n                    lineNumber: 16,\n                    columnNumber: 17\n                }, this)\n            ]\n        }, void 0, true, {\n            fileName: \"C:\\\\Users\\\\코드캠프\\\\Desktop\\\\codecamp fe-06\\\\quiz\\\\pages\\\\13-4slide\\\\index.tsx\",\n            lineNumber: 14,\n            columnNumber: 13\n        }, this));\n    }\n}\n\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy8xMy00c2xpZGUvaW5kZXgudHN4LmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7O0FBQXdDO0FBQ1I7TUFFWEcsWUFBWSxTQUFTRiw0Q0FBUztJQUMvQ0csTUFBTSxHQUFHLENBQUM7UUFDTixLQUFLLENBQUNDLFFBQVEsR0FBRyxDQUFDO1lBQ2RDLElBQUksRUFBRSxJQUFJO1lBQ1ZDLFFBQVEsRUFBRSxJQUFJO1lBQ2RDLEtBQUssRUFBRSxHQUFHO1lBQ1ZDLFlBQVksRUFBRSxDQUFDO1lBQ2ZDLGNBQWMsRUFBRSxDQUFDO1FBQ3JCLENBQUM7UUFDRCxNQUFNLDZFQUNEQyxDQUFHOzs0RkFDQ0MsQ0FBRTs4QkFBQyxDQUFJOzs7Ozs7NEZBQ1BWLG9EQUFNO3VCQUFLRyxRQUFROztvR0FDZk0sQ0FBRztrSEFDQ0UsQ0FBRTswQ0FBQyxDQUFDOzs7Ozs7Ozs7OztvR0FFUkYsQ0FBRztrSEFDQ0UsQ0FBRTswQ0FBQyxDQUFDOzs7Ozs7Ozs7OztvR0FFUkYsQ0FBRztrSEFDQ0UsQ0FBRTswQ0FBQyxDQUFDOzs7Ozs7Ozs7OztvR0FFUkYsQ0FBRztrSEFDQ0UsQ0FBRTswQ0FBQyxDQUFDOzs7Ozs7Ozs7OztvR0FFUkYsQ0FBRztrSEFDQ0UsQ0FBRTswQ0FBQyxDQUFDOzs7Ozs7Ozs7OztvR0FFUkYsQ0FBRztrSEFDQ0UsQ0FBRTswQ0FBQyxDQUFDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztJQUt6QixDQUFDOztBQWxDNEIiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9jbGFzcy8uL3BhZ2VzLzEzLTRzbGlkZS9pbmRleC50c3g/MThlMyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgQ29tcG9uZW50IH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBTbGlkZXIgZnJvbSBcInJlYWN0LXNsaWNrXCI7XHJcblxyXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBTaW1wbGVTbGlkZXIgZXh0ZW5kcyBDb21wb25lbnQge1xyXG4gICAgcmVuZGVyKCkge1xyXG4gICAgICAgIGNvbnN0IHNldHRpbmdzID0ge1xyXG4gICAgICAgICAgICBkb3RzOiB0cnVlLFxyXG4gICAgICAgICAgICBpbmZpbml0ZTogdHJ1ZSxcclxuICAgICAgICAgICAgc3BlZWQ6IDUwMCxcclxuICAgICAgICAgICAgc2xpZGVzVG9TaG93OiAxLFxyXG4gICAgICAgICAgICBzbGlkZXNUb1Njcm9sbDogMSxcclxuICAgICAgICB9O1xyXG4gICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8aDI+IHNyYzwvaDI+XHJcbiAgICAgICAgICAgICAgICA8U2xpZGVyIHsuLi5zZXR0aW5nc30+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGgzPjE8L2gzPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxoMz4yPC9oMz5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aDM+MzwvaDM+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGgzPjQ8L2gzPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxoMz41PC9oMz5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aDM+NjwvaDM+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L1NsaWRlcj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgKTtcclxuICAgIH1cclxufVxyXG4iXSwibmFtZXMiOlsiUmVhY3QiLCJDb21wb25lbnQiLCJTbGlkZXIiLCJTaW1wbGVTbGlkZXIiLCJyZW5kZXIiLCJzZXR0aW5ncyIsImRvdHMiLCJpbmZpbml0ZSIsInNwZWVkIiwic2xpZGVzVG9TaG93Iiwic2xpZGVzVG9TY3JvbGwiLCJkaXYiLCJoMiIsImgzIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./pages/13-4slide/index.tsx\n");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ "react-slick":
/*!******************************!*\
  !*** external "react-slick" ***!
  \******************************/
/***/ ((module) => {

module.exports = require("react-slick");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/13-4slide/index.tsx"));
module.exports = __webpack_exports__;

})();