"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/22-02-loginsuccess";
exports.ids = ["pages/22-02-loginsuccess"];
exports.modules = {

/***/ "./pages/22-02-loginsuccess/index.tsx":
/*!********************************************!*\
  !*** ./pages/22-02-loginsuccess/index.tsx ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ LoginSuccessPage)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @apollo/client */ \"@apollo/client\");\n/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_apollo_client__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/router */ \"next/router\");\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);\n/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! recoil */ \"recoil\");\n/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(recoil__WEBPACK_IMPORTED_MODULE_4__);\n/* harmony import */ var _src_commons_store__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../src/commons/store */ \"./src/commons/store/index.ts\");\n\n\n\n\n\n\nconst FETCH_USER_LOGGED_IN = _apollo_client__WEBPACK_IMPORTED_MODULE_1__.gql`\n    query fetchUserLoggedIn {\n        fetchUserLoggedIn {\n            email\n            name\n        }\n    }\n`;\nfunction LoginSuccessPage() {\n    const { data  } = (0,_apollo_client__WEBPACK_IMPORTED_MODULE_1__.useQuery)(FETCH_USER_LOGGED_IN);\n    const [accessToken] = (0,recoil__WEBPACK_IMPORTED_MODULE_4__.useRecoilState)(_src_commons_store__WEBPACK_IMPORTED_MODULE_5__.accessTokenState);\n    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{\n        if (!accessToken) {\n            alert(\"어서!돌아가 로그인고고\");\n            next_router__WEBPACK_IMPORTED_MODULE_2___default().push(\"22-01loginpage\");\n        }\n    }, [\n        accessToken\n    ]);\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        children: \"캠프입장완료 환영해요\"\n    }, void 0, false, {\n        fileName: \"C:\\\\Users\\\\코드캠프\\\\Desktop\\\\codecamp fe-06\\\\quiz\\\\pages\\\\22-02-loginsuccess\\\\index.tsx\",\n        lineNumber: 27,\n        columnNumber: 12\n    }, this));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy8yMi0wMi1sb2dpbnN1Y2Nlc3MvaW5kZXgudHN4LmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBOEM7QUFDZDtBQUNDO0FBQ007QUFDbUI7QUFFMUQsS0FBSyxDQUFDTSxvQkFBb0IsR0FBR0wsK0NBQUcsQ0FBQzs7Ozs7OztBQU9qQztBQUVlLFFBQVEsQ0FBQ00sZ0JBQWdCLEdBQUcsQ0FBQztJQUN4QyxLQUFLLENBQUMsQ0FBQyxDQUFDQyxJQUFJLEVBQUMsQ0FBQyxHQUFHUix3REFBUSxDQUFDTSxvQkFBb0I7SUFDOUMsS0FBSyxFQUFFRyxXQUFXLElBQUlMLHNEQUFjLENBQUNDLGdFQUFnQjtJQUVyREYsZ0RBQVMsS0FBTyxDQUFDO1FBQ2IsRUFBRSxHQUFHTSxXQUFXLEVBQUUsQ0FBQztZQUNmQyxLQUFLLENBQUMsQ0FBYztZQUNBUix1REFBVCxDQUFDLENBQWdCO1FBQ2hDLENBQUM7SUFDTCxDQUFDLEVBQUUsQ0FBQ087UUFBQUEsV0FBVztJQUFBLENBQUM7SUFFaEIsTUFBTSw2RUFBRUcsQ0FBRztrQkFBQyxDQUFXOzs7Ozs7QUFDM0IsQ0FBQyIsInNvdXJjZXMiOlsid2VicGFjazovL2NsYXNzLy4vcGFnZXMvMjItMDItbG9naW5zdWNjZXNzL2luZGV4LnRzeD8xNTFmIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVF1ZXJ5LCBncWwgfSBmcm9tIFwiQGFwb2xsby9jbGllbnRcIjtcclxuaW1wb3J0IHJvdXRlciBmcm9tIFwibmV4dC9yb3V0ZXJcIjtcclxuaW1wb3J0IHsgdXNlRWZmZWN0IH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IHVzZVJlY29pbFN0YXRlIH0gZnJvbSBcInJlY29pbFwiO1xyXG5pbXBvcnQgeyBhY2Nlc3NUb2tlblN0YXRlIH0gZnJvbSBcIi4uLy4uL3NyYy9jb21tb25zL3N0b3JlXCI7XHJcblxyXG5jb25zdCBGRVRDSF9VU0VSX0xPR0dFRF9JTiA9IGdxbGBcclxuICAgIHF1ZXJ5IGZldGNoVXNlckxvZ2dlZEluIHtcclxuICAgICAgICBmZXRjaFVzZXJMb2dnZWRJbiB7XHJcbiAgICAgICAgICAgIGVtYWlsXHJcbiAgICAgICAgICAgIG5hbWVcclxuICAgICAgICB9XHJcbiAgICB9XHJcbmA7XHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBMb2dpblN1Y2Nlc3NQYWdlKCkge1xyXG4gICAgY29uc3QgeyBkYXRhIH0gPSB1c2VRdWVyeShGRVRDSF9VU0VSX0xPR0dFRF9JTik7XHJcbiAgICBjb25zdCBbYWNjZXNzVG9rZW5dID0gdXNlUmVjb2lsU3RhdGUoYWNjZXNzVG9rZW5TdGF0ZSk7XHJcblxyXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgICAgICBpZiAoIWFjY2Vzc1Rva2VuKSB7XHJcbiAgICAgICAgICAgIGFsZXJ0KFwi7Ja07IScIeuPjOyVhOqwgCDroZzqt7jsnbjqs6Dqs6BcIik7XHJcbiAgICAgICAgICAgIHJvdXRlci5wdXNoKFwiMjItMDFsb2dpbnBhZ2VcIik7XHJcbiAgICAgICAgfVxyXG4gICAgfSwgW2FjY2Vzc1Rva2VuXSk7XHJcblxyXG4gICAgcmV0dXJuIDxkaXY+7Lqg7ZSE7J6F7J6l7JmE66OMIO2ZmOyYge2VtOyalDwvZGl2PjtcclxufVxyXG4iXSwibmFtZXMiOlsidXNlUXVlcnkiLCJncWwiLCJyb3V0ZXIiLCJ1c2VFZmZlY3QiLCJ1c2VSZWNvaWxTdGF0ZSIsImFjY2Vzc1Rva2VuU3RhdGUiLCJGRVRDSF9VU0VSX0xPR0dFRF9JTiIsIkxvZ2luU3VjY2Vzc1BhZ2UiLCJkYXRhIiwiYWNjZXNzVG9rZW4iLCJhbGVydCIsInB1c2giLCJkaXYiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./pages/22-02-loginsuccess/index.tsx\n");

/***/ }),

/***/ "./src/commons/store/index.ts":
/*!************************************!*\
  !*** ./src/commons/store/index.ts ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"isEditState\": () => (/* binding */ isEditState),\n/* harmony export */   \"accessTokenState\": () => (/* binding */ accessTokenState)\n/* harmony export */ });\n/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! recoil */ \"recoil\");\n/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(recoil__WEBPACK_IMPORTED_MODULE_0__);\n\nconst isEditState = (0,recoil__WEBPACK_IMPORTED_MODULE_0__.atom)({\n    key: \"isEditState\",\n    default: false\n});\nconst accessTokenState = (0,recoil__WEBPACK_IMPORTED_MODULE_0__.atom)({\n    key: \"accessTokenState\",\n    default: \"\"\n}); // 글로벌 스테이트 isEditState 로 만든다 아톰으로\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvY29tbW9ucy9zdG9yZS9pbmRleC50cy5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7O0FBQTZCO0FBRXRCLEtBQUssQ0FBQ0MsV0FBVyxHQUFHRCw0Q0FBSSxDQUFDLENBQUM7SUFDN0JFLEdBQUcsRUFBRSxDQUFhO0lBQ2xCQyxPQUFPLEVBQUUsS0FBSztBQUNsQixDQUFDO0FBRU0sS0FBSyxDQUFDQyxnQkFBZ0IsR0FBR0osNENBQUksQ0FBQyxDQUFDO0lBQ2xDRSxHQUFHLEVBQUUsQ0FBa0I7SUFDdkJDLE9BQU8sRUFBRSxDQUFFO0FBQ2YsQ0FBQyxFQUNELENBQWtDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vY2xhc3MvLi9zcmMvY29tbW9ucy9zdG9yZS9pbmRleC50cz8zY2JmIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGF0b20gfSBmcm9tIFwicmVjb2lsXCI7XHJcblxyXG5leHBvcnQgY29uc3QgaXNFZGl0U3RhdGUgPSBhdG9tKHtcclxuICAgIGtleTogXCJpc0VkaXRTdGF0ZVwiLFxyXG4gICAgZGVmYXVsdDogZmFsc2UsXHJcbn0pO1xyXG5cclxuZXhwb3J0IGNvbnN0IGFjY2Vzc1Rva2VuU3RhdGUgPSBhdG9tKHtcclxuICAgIGtleTogXCJhY2Nlc3NUb2tlblN0YXRlXCIsXHJcbiAgICBkZWZhdWx0OiBcIlwiLFxyXG59KTtcclxuLy8g6riA66Gc67KMIOyKpO2FjOydtO2KuCBpc0VkaXRTdGF0ZSDroZwg66eM65Og64ukIOyVhO2GsOycvOuhnFxyXG4iXSwibmFtZXMiOlsiYXRvbSIsImlzRWRpdFN0YXRlIiwia2V5IiwiZGVmYXVsdCIsImFjY2Vzc1Rva2VuU3RhdGUiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./src/commons/store/index.ts\n");

/***/ }),

/***/ "@apollo/client":
/*!*********************************!*\
  !*** external "@apollo/client" ***!
  \*********************************/
/***/ ((module) => {

module.exports = require("@apollo/client");

/***/ }),

/***/ "next/router":
/*!******************************!*\
  !*** external "next/router" ***!
  \******************************/
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ }),

/***/ "recoil":
/*!*************************!*\
  !*** external "recoil" ***!
  \*************************/
/***/ ((module) => {

module.exports = require("recoil");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/22-02-loginsuccess/index.tsx"));
module.exports = __webpack_exports__;

})();