import styled from "@emotion/styled";

const Wrapper = styled.div`
    height: 150px;
    background-color: orange;
    font-family: "myfont";
`;

export default function LayoutNavigation() {
    return <Wrapper></Wrapper>;
}
