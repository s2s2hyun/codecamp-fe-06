import GlobalStatePresenter from "./write.presenter";

export default function GlobalStateContainer() {
    return <GlobalStatePresenter />;
}
