//여기는 수정하기 페이지

import ProductWrite from "../../../../src/components/units/product/09-product-write/productWrite.container";

export default function ProductsEditPage() {
    return <ProductWrite isEdit={true} />;
}
