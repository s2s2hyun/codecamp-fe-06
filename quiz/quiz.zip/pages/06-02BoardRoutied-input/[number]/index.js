import BoardRead from "../../../src/units/board/read/BoardRead.container";

export default function StaticRoutedPage() {
    return <BoardRead />;
}
