export default function OneBodyPage() {
    return <>One바디영역</>;
}
