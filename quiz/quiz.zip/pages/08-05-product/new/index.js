// 여기는 등록하기 페이지

import ProductWrite from "../../../src/components/units/product/08-product-write/productWrite.container";

export default function ProductsNewPage() {
    return <ProductWrite isEdit={false} />;
}
