import BoardWrite from "../../src/units/board/write/BoardWrite.container";

export default function GraphqlMutationPage() {
    return <BoardWrite />;
}
