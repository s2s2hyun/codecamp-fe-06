export default function FunctionalComponentChildPage(gank) {
    return (
        <div>
            {gank.child}는 {gank.age}살 입니다.
        </div>
    );
}
