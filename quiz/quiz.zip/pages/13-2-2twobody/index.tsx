export default function TwoBodyPage() {
    return <>Two바디영역</>;
}
