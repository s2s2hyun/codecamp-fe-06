export default function ThreeBodyPage() {
    return <>Three바디영역</>;
}
