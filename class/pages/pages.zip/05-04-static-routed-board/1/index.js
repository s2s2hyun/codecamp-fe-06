export default function StaticRoutedPage() {

    return(
        <div>1번게시글을 오신걸 환영합니다!!</div>
    )
}