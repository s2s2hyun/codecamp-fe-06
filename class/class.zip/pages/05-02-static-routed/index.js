export default function StaticRoutedPage() {

    return(
        <div>페이지 이동이 완료되었습니다.!!</div>
    )
}