import BoardComponent from "../../src/components/units/board/08-board-component/BoardComponent";

export default function BoardEditPage() {
    return <BoardComponent isEdit={true} />;
}
