import { MyTitle, MyEmail } from '../../styles/emotion'




export default function AAApage() {



  //여기는 자바스크립트 쓰는곳 //
  
  
    return (
        <MyTitle>
            안녕하세요
            <input type="text"/>
        </MyTitle>
  )
}
