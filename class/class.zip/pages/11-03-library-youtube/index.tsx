import React from "react";
import ReactPlayer from "react-player";

export default function LibraryYoutubePage() {
  return (
    <ReactPlayer
      url="https://www.youtube.com/watch?v=zShv8onwVe0"
      width={900}
      heigth={900}
    />
  );
}

// youtube url 사이즈는 ㅇ ㅕ기서만 설정이 가능하다
