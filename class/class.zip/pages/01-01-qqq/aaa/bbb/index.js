export default function AAApage() {
  
  
  //여기는 자바스크립트 쓰는곳 //
  
  
    return (
        <div >
            안녕하세요 !!!
            <input type="text"/>
        </div>
  )
}
