// 여기는 등록하기 페이지

import BoardWrite from "../../../src/components/units/board/09-board-write/BoardWrite.container";

export default function BoardsNewPage() {
    return <BoardWrite isEdit={false} />;
}
