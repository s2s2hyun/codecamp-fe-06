export default function BoardEditPage() {
    return (
        <div>
            <h1>수정페이지</h1>
            제목: <input type="text" />
            <br />
            내용: <input type="text" />
            <br />
            <button>수정하기</button>
        </div>
    );
}
