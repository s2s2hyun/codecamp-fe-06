//여기는 수정하기 페이지

import BoardWrite from "../../../../src/components/units/board/08-board-write/BoardWrite.container";

export default function BoardsEditPage() {
    return <BoardWrite isEdit={true} />;
}
