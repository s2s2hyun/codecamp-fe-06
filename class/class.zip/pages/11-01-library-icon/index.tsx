import { QuestionCircleOutlined } from "@ant-design/icons";
import styled from "@emotion/styled";

const MyIcon = styled(QuestionCircleOutlined)`
  // font-size:50px;
  // color:red;
  //
`;

export default function LibraryIconPage() {
  return <MyIcon />;
  //   <QuestionCircleOutlined />;
}

// 물음표 아이콘
//<QuestionCircleOutlined id="eqwhje"/>;
//아이디 작성하지말고 그냥 못쓴다고 생각을 하자
// import styled from '@emotion/styled'
// const MyIcon = styled(QuestionCircleOutlined)`
// font-size:50px;
// color:red;
// `
