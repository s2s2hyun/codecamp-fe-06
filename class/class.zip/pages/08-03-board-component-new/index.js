import BoardComponent from "../../src/components/units/board/08-board-component/BoardComponent";

export default function BoardNewPage() {
    return <BoardComponent isEdit={false} />;
}
