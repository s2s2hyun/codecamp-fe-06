/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/_app";
exports.ids = ["pages/_app"];
exports.modules = {

/***/ "./pages/_app.tsx":
/*!************************!*\
  !*** ./pages/_app.tsx ***!
  \************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"firebaseApp\": () => (/* binding */ firebaseApp),\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var antd_dist_antd_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! antd/dist/antd.css */ \"./node_modules/antd/dist/antd.css\");\n/* harmony import */ var antd_dist_antd_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(antd_dist_antd_css__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @apollo/client */ \"@apollo/client\");\n/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_apollo_client__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var _src_components_units_commons_layout__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../src/components/units/commons/layout */ \"./src/components/units/commons/layout/index.tsx\");\n/* harmony import */ var _emotion_react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @emotion/react */ \"@emotion/react\");\n/* harmony import */ var _emotion_react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_emotion_react__WEBPACK_IMPORTED_MODULE_4__);\n/* harmony import */ var _src_commons_styles_globalStyles__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../src/commons/styles/globalStyles */ \"./src/commons/styles/globalStyles.ts\");\n/* harmony import */ var apollo_upload_client__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! apollo-upload-client */ \"apollo-upload-client\");\n/* harmony import */ var firebase_app__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! firebase/app */ \"firebase/app\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([apollo_upload_client__WEBPACK_IMPORTED_MODULE_6__, firebase_app__WEBPACK_IMPORTED_MODULE_7__]);\n([apollo_upload_client__WEBPACK_IMPORTED_MODULE_6__, firebase_app__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);\n\n\n// import '../styles/globals.css';\n\n\n\n\n\n// Import the functions you need from the SDKs you need\n// Import the functions you need from the SDKs you need\n\n// TODO: Add SDKs for Firebase products that you want to use\n// https://firebase.google.com/docs/web/setup#available-libraries\n// Your web app's Firebase configuration\nconst firebaseConfig = {\n    apiKey: \"AIzaSyDDs1YvmiRstnwx2wxeBVKeKHjFMdHXpyc\",\n    authDomain: \"projectbean-54aa5.firebaseapp.com\",\n    projectId: \"projectbean-54aa5\",\n    storageBucket: \"projectbean-54aa5.appspot.com\",\n    messagingSenderId: \"453409820013\",\n    appId: \"1:453409820013:web:a7db1cc59d6696ccc31e64\"\n};\n// Initialize Firebase\nconst firebaseApp = (0,firebase_app__WEBPACK_IMPORTED_MODULE_7__.initializeApp)(firebaseConfig);\nfunction MyApp({ Component , pageProps  }) {\n    const uploadLink = (0,apollo_upload_client__WEBPACK_IMPORTED_MODULE_6__.createUploadLink)({\n        uri: \"http://backend06.codebootcamp.co.kr/graphql\"\n    });\n    const client = new _apollo_client__WEBPACK_IMPORTED_MODULE_2__.ApolloClient({\n        link: _apollo_client__WEBPACK_IMPORTED_MODULE_2__.ApolloLink.from([\n            uploadLink\n        ]),\n        // uri: \"http://backend06.codebootcamp.co.kr/graphql\",\n        cache: new _apollo_client__WEBPACK_IMPORTED_MODULE_2__.InMemoryCache()\n    });\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_apollo_client__WEBPACK_IMPORTED_MODULE_2__.ApolloProvider, {\n        client: client,\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_emotion_react__WEBPACK_IMPORTED_MODULE_4__.Global, {\n                styles: _src_commons_styles_globalStyles__WEBPACK_IMPORTED_MODULE_5__.globalStyles\n            }, void 0, false, {\n                fileName: \"C:\\\\Users\\\\코드캠프\\\\Desktop\\\\codecamp fe-06\\\\class\\\\pages\\\\_app.tsx\",\n                lineNumber: 46,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_src_components_units_commons_layout__WEBPACK_IMPORTED_MODULE_3__[\"default\"], {\n                children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Component, {\n                    ...pageProps\n                }, void 0, false, {\n                    fileName: \"C:\\\\Users\\\\코드캠프\\\\Desktop\\\\codecamp fe-06\\\\class\\\\pages\\\\_app.tsx\",\n                    lineNumber: 48,\n                    columnNumber: 9\n                }, this)\n            }, void 0, false, {\n                fileName: \"C:\\\\Users\\\\코드캠프\\\\Desktop\\\\codecamp fe-06\\\\class\\\\pages\\\\_app.tsx\",\n                lineNumber: 47,\n                columnNumber: 7\n            }, this)\n        ]\n    }, void 0, true, {\n        fileName: \"C:\\\\Users\\\\코드캠프\\\\Desktop\\\\codecamp fe-06\\\\class\\\\pages\\\\_app.tsx\",\n        lineNumber: 45,\n        columnNumber: 5\n    }, this));\n}\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MyApp);\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9fYXBwLnRzeC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBMkI7QUFDM0IsRUFBa0M7QUFNWDtBQUVvQztBQUNwQjtBQUMwQjtBQUNWO0FBQ3ZELEVBQXVEO0FBQ3ZELEVBQXVEO0FBQ1g7QUFDNUMsRUFBNEQ7QUFDNUQsRUFBaUU7QUFFakUsRUFBd0M7QUFDeEMsS0FBSyxDQUFDUyxjQUFjLEdBQUcsQ0FBQztJQUN0QkMsTUFBTSxFQUFFLENBQXlDO0lBQ2pEQyxVQUFVLEVBQUUsQ0FBbUM7SUFDL0NDLFNBQVMsRUFBRSxDQUFtQjtJQUM5QkMsYUFBYSxFQUFFLENBQStCO0lBQzlDQyxpQkFBaUIsRUFBRSxDQUFjO0lBQ2pDQyxLQUFLLEVBQUUsQ0FBMkM7QUFDcEQsQ0FBQztBQUVELEVBQXNCO0FBQ2YsS0FBSyxDQUFDQyxXQUFXLEdBQUdSLDJEQUFhLENBQUNDLGNBQWM7U0FFOUNRLEtBQUssQ0FBQyxDQUFDLENBQUNDLFNBQVMsR0FBRUMsU0FBUyxFQUFXLENBQUMsRUFBRSxDQUFDO0lBQ2xELEtBQUssQ0FBQ0MsVUFBVSxHQUFHYixzRUFBZ0IsQ0FBQyxDQUFDO1FBQ25DYyxHQUFHLEVBQUUsQ0FBNkM7SUFDcEQsQ0FBQztJQUVELEtBQUssQ0FBQ0MsTUFBTSxHQUFHLEdBQUcsQ0FBQ3RCLHdEQUFZLENBQUMsQ0FBQztRQUMvQnVCLElBQUksRUFBRXRCLDJEQUFlLENBQUMsQ0FBQ21CO1lBQUFBLFVBQVU7UUFBQSxDQUFDO1FBQ2xDLEVBQXNEO1FBQ3RESyxLQUFLLEVBQUUsR0FBRyxDQUFDdEIseURBQWE7SUFDMUIsQ0FBQztJQUVELE1BQU0sNkVBQ0hELDBEQUFjO1FBQUNvQixNQUFNLEVBQUVBLE1BQU07O3dGQUMzQmpCLGtEQUFNO2dCQUFDcUIsTUFBTSxFQUFFcEIsMEVBQVk7Ozs7Ozt3RkFDM0JGLDRFQUFNO3NHQUNKYyxTQUFTO3VCQUFLQyxTQUFTOzs7Ozs7Ozs7Ozs7Ozs7OztBQUloQyxDQUFDO0FBRUQsaUVBQWVGLEtBQUssRUFBQyIsInNvdXJjZXMiOlsid2VicGFjazovL2NsYXNzLy4vcGFnZXMvX2FwcC50c3g/MmZiZSJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgXCJhbnRkL2Rpc3QvYW50ZC5jc3NcIjtcclxuLy8gaW1wb3J0ICcuLi9zdHlsZXMvZ2xvYmFscy5jc3MnO1xyXG5pbXBvcnQge1xyXG4gIEFwb2xsb0NsaWVudCxcclxuICBBcG9sbG9MaW5rLFxyXG4gIEFwb2xsb1Byb3ZpZGVyLFxyXG4gIEluTWVtb3J5Q2FjaGUsXHJcbn0gZnJvbSBcIkBhcG9sbG8vY2xpZW50XCI7XHJcbmltcG9ydCB7IEFwcFByb3BzIH0gZnJvbSBcIm5leHQvYXBwXCI7XHJcbmltcG9ydCBMYXlvdXQgZnJvbSBcIi4uL3NyYy9jb21wb25lbnRzL3VuaXRzL2NvbW1vbnMvbGF5b3V0XCI7XHJcbmltcG9ydCB7IEdsb2JhbCB9IGZyb20gXCJAZW1vdGlvbi9yZWFjdFwiO1xyXG5pbXBvcnQgeyBnbG9iYWxTdHlsZXMgfSBmcm9tIFwiLi4vc3JjL2NvbW1vbnMvc3R5bGVzL2dsb2JhbFN0eWxlc1wiO1xyXG5pbXBvcnQgeyBjcmVhdGVVcGxvYWRMaW5rIH0gZnJvbSBcImFwb2xsby11cGxvYWQtY2xpZW50XCI7XHJcbi8vIEltcG9ydCB0aGUgZnVuY3Rpb25zIHlvdSBuZWVkIGZyb20gdGhlIFNES3MgeW91IG5lZWRcclxuLy8gSW1wb3J0IHRoZSBmdW5jdGlvbnMgeW91IG5lZWQgZnJvbSB0aGUgU0RLcyB5b3UgbmVlZFxyXG5pbXBvcnQgeyBpbml0aWFsaXplQXBwIH0gZnJvbSBcImZpcmViYXNlL2FwcFwiO1xyXG4vLyBUT0RPOiBBZGQgU0RLcyBmb3IgRmlyZWJhc2UgcHJvZHVjdHMgdGhhdCB5b3Ugd2FudCB0byB1c2VcclxuLy8gaHR0cHM6Ly9maXJlYmFzZS5nb29nbGUuY29tL2RvY3Mvd2ViL3NldHVwI2F2YWlsYWJsZS1saWJyYXJpZXNcclxuXHJcbi8vIFlvdXIgd2ViIGFwcCdzIEZpcmViYXNlIGNvbmZpZ3VyYXRpb25cclxuY29uc3QgZmlyZWJhc2VDb25maWcgPSB7XHJcbiAgYXBpS2V5OiBcIkFJemFTeUREczFZdm1pUnN0bnd4Mnd4ZUJWS2VLSGpGTWRIWHB5Y1wiLFxyXG4gIGF1dGhEb21haW46IFwicHJvamVjdGJlYW4tNTRhYTUuZmlyZWJhc2VhcHAuY29tXCIsXHJcbiAgcHJvamVjdElkOiBcInByb2plY3RiZWFuLTU0YWE1XCIsXHJcbiAgc3RvcmFnZUJ1Y2tldDogXCJwcm9qZWN0YmVhbi01NGFhNS5hcHBzcG90LmNvbVwiLFxyXG4gIG1lc3NhZ2luZ1NlbmRlcklkOiBcIjQ1MzQwOTgyMDAxM1wiLFxyXG4gIGFwcElkOiBcIjE6NDUzNDA5ODIwMDEzOndlYjphN2RiMWNjNTlkNjY5NmNjYzMxZTY0XCIsXHJcbn07XHJcblxyXG4vLyBJbml0aWFsaXplIEZpcmViYXNlXHJcbmV4cG9ydCBjb25zdCBmaXJlYmFzZUFwcCA9IGluaXRpYWxpemVBcHAoZmlyZWJhc2VDb25maWcpO1xyXG5cclxuZnVuY3Rpb24gTXlBcHAoeyBDb21wb25lbnQsIHBhZ2VQcm9wcyB9OiBBcHBQcm9wcykge1xyXG4gIGNvbnN0IHVwbG9hZExpbmsgPSBjcmVhdGVVcGxvYWRMaW5rKHtcclxuICAgIHVyaTogXCJodHRwOi8vYmFja2VuZDA2LmNvZGVib290Y2FtcC5jby5rci9ncmFwaHFsXCIsXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IGNsaWVudCA9IG5ldyBBcG9sbG9DbGllbnQoe1xyXG4gICAgbGluazogQXBvbGxvTGluay5mcm9tKFt1cGxvYWRMaW5rXSksXHJcbiAgICAvLyB1cmk6IFwiaHR0cDovL2JhY2tlbmQwNi5jb2RlYm9vdGNhbXAuY28ua3IvZ3JhcGhxbFwiLFxyXG4gICAgY2FjaGU6IG5ldyBJbk1lbW9yeUNhY2hlKCksXHJcbiAgfSk7XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8QXBvbGxvUHJvdmlkZXIgY2xpZW50PXtjbGllbnR9PlxyXG4gICAgICA8R2xvYmFsIHN0eWxlcz17Z2xvYmFsU3R5bGVzfSAvPlxyXG4gICAgICA8TGF5b3V0PlxyXG4gICAgICAgIDxDb21wb25lbnQgey4uLnBhZ2VQcm9wc30gLz5cclxuICAgICAgPC9MYXlvdXQ+XHJcbiAgICA8L0Fwb2xsb1Byb3ZpZGVyPlxyXG4gICk7XHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IE15QXBwO1xyXG4iXSwibmFtZXMiOlsiQXBvbGxvQ2xpZW50IiwiQXBvbGxvTGluayIsIkFwb2xsb1Byb3ZpZGVyIiwiSW5NZW1vcnlDYWNoZSIsIkxheW91dCIsIkdsb2JhbCIsImdsb2JhbFN0eWxlcyIsImNyZWF0ZVVwbG9hZExpbmsiLCJpbml0aWFsaXplQXBwIiwiZmlyZWJhc2VDb25maWciLCJhcGlLZXkiLCJhdXRoRG9tYWluIiwicHJvamVjdElkIiwic3RvcmFnZUJ1Y2tldCIsIm1lc3NhZ2luZ1NlbmRlcklkIiwiYXBwSWQiLCJmaXJlYmFzZUFwcCIsIk15QXBwIiwiQ29tcG9uZW50IiwicGFnZVByb3BzIiwidXBsb2FkTGluayIsInVyaSIsImNsaWVudCIsImxpbmsiLCJmcm9tIiwiY2FjaGUiLCJzdHlsZXMiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./pages/_app.tsx\n");

/***/ }),

/***/ "./src/commons/styles/globalStyles.ts":
/*!********************************************!*\
  !*** ./src/commons/styles/globalStyles.ts ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"globalStyles\": () => (/* binding */ globalStyles)\n/* harmony export */ });\n/* harmony import */ var _emotion_react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @emotion/react */ \"@emotion/react\");\n/* harmony import */ var _emotion_react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_emotion_react__WEBPACK_IMPORTED_MODULE_0__);\n\nconst globalStyles = _emotion_react__WEBPACK_IMPORTED_MODULE_0__.css`\n  * {\n    margin: 0;\n    box-sizing: boder-box;\n    font-size: 22px;\n    font-family: \"myfont\";\n  }\n\n  @font-face {\n    font-family: \"myfont\";\n    src: url(\"/fonts/scifibit.ttf\");\n  }\n`;\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvY29tbW9ucy9zdHlsZXMvZ2xvYmFsU3R5bGVzLnRzLmpzIiwibWFwcGluZ3MiOiI7Ozs7OztBQUFvQztBQUU3QixLQUFLLENBQUNDLFlBQVksR0FBR0QsK0NBQUcsQ0FBQzs7Ozs7Ozs7Ozs7O0FBWWhDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vY2xhc3MvLi9zcmMvY29tbW9ucy9zdHlsZXMvZ2xvYmFsU3R5bGVzLnRzP2M3NzUiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgY3NzIH0gZnJvbSBcIkBlbW90aW9uL3JlYWN0XCI7XHJcblxyXG5leHBvcnQgY29uc3QgZ2xvYmFsU3R5bGVzID0gY3NzYFxyXG4gICoge1xyXG4gICAgbWFyZ2luOiAwO1xyXG4gICAgYm94LXNpemluZzogYm9kZXItYm94O1xyXG4gICAgZm9udC1zaXplOiAyMnB4O1xyXG4gICAgZm9udC1mYW1pbHk6IFwibXlmb250XCI7XHJcbiAgfVxyXG5cclxuICBAZm9udC1mYWNlIHtcclxuICAgIGZvbnQtZmFtaWx5OiBcIm15Zm9udFwiO1xyXG4gICAgc3JjOiB1cmwoXCIvZm9udHMvc2NpZmliaXQudHRmXCIpO1xyXG4gIH1cclxuYDtcclxuIl0sIm5hbWVzIjpbImNzcyIsImdsb2JhbFN0eWxlcyJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./src/commons/styles/globalStyles.ts\n");

/***/ }),

/***/ "./src/components/units/commons/layout/banner/index.tsx":
/*!**************************************************************!*\
  !*** ./src/components/units/commons/layout/banner/index.tsx ***!
  \**************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ LayoutBanner)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @emotion/styled */ \"@emotion/styled\");\n/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_emotion_styled__WEBPACK_IMPORTED_MODULE_1__);\n\n\nconst Wrapper = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`\n  height: 50px;\n  background-color: yellow;\n`;\nfunction LayoutBanner() {\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Wrapper, {\n        children: \"여기는 배너 영역 입니다jkljl.\"\n    }, void 0, false, {\n        fileName: \"C:\\\\Users\\\\코드캠프\\\\Desktop\\\\codecamp fe-06\\\\class\\\\src\\\\components\\\\units\\\\commons\\\\layout\\\\banner\\\\index.tsx\",\n        lineNumber: 9,\n        columnNumber: 10\n    }, this));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvY29tcG9uZW50cy91bml0cy9jb21tb25zL2xheW91dC9iYW5uZXIvaW5kZXgudHN4LmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7OztBQUFvQztBQUVwQyxLQUFLLENBQUNDLE9BQU8sR0FBR0QsNERBQVUsQ0FBQzs7O0FBRzNCO0FBRWUsUUFBUSxDQUFDRyxZQUFZLEdBQUcsQ0FBQztJQUN0QyxNQUFNLDZFQUFFRixPQUFPO2tCQUFDLENBQW1COzs7Ozs7QUFDckMsQ0FBQyIsInNvdXJjZXMiOlsid2VicGFjazovL2NsYXNzLy4vc3JjL2NvbXBvbmVudHMvdW5pdHMvY29tbW9ucy9sYXlvdXQvYmFubmVyL2luZGV4LnRzeD8wZDIwIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBzdHlsZWQgZnJvbSBcIkBlbW90aW9uL3N0eWxlZFwiO1xyXG5cclxuY29uc3QgV3JhcHBlciA9IHN0eWxlZC5kaXZgXHJcbiAgaGVpZ2h0OiA1MHB4O1xyXG4gIGJhY2tncm91bmQtY29sb3I6IHllbGxvdztcclxuYDtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIExheW91dEJhbm5lcigpIHtcclxuICByZXR1cm4gPFdyYXBwZXI+7Jes6riw64qUIOuwsOuEiCDsmIHsl60g7J6F64uI64ukamtsamwuPC9XcmFwcGVyPjtcclxufVxyXG4iXSwibmFtZXMiOlsic3R5bGVkIiwiV3JhcHBlciIsImRpdiIsIkxheW91dEJhbm5lciJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./src/components/units/commons/layout/banner/index.tsx\n");

/***/ }),

/***/ "./src/components/units/commons/layout/footer/index.tsx":
/*!**************************************************************!*\
  !*** ./src/components/units/commons/layout/footer/index.tsx ***!
  \**************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ Layoutfooter)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @emotion/styled */ \"@emotion/styled\");\n/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_emotion_styled__WEBPACK_IMPORTED_MODULE_1__);\n\n\nconst Wrapper = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`\n  height: 50px;\n  background-color: gray;\n`;\nfunction Layoutfooter() {\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Wrapper, {\n        children: \"여기는 푸터 영역 입니다.\"\n    }, void 0, false, {\n        fileName: \"C:\\\\Users\\\\코드캠프\\\\Desktop\\\\codecamp fe-06\\\\class\\\\src\\\\components\\\\units\\\\commons\\\\layout\\\\footer\\\\index.tsx\",\n        lineNumber: 9,\n        columnNumber: 10\n    }, this));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvY29tcG9uZW50cy91bml0cy9jb21tb25zL2xheW91dC9mb290ZXIvaW5kZXgudHN4LmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7OztBQUFvQztBQUVwQyxLQUFLLENBQUNDLE9BQU8sR0FBR0QsNERBQVUsQ0FBQzs7O0FBRzNCO0FBRWUsUUFBUSxDQUFDRyxZQUFZLEdBQUcsQ0FBQztJQUN0QyxNQUFNLDZFQUFFRixPQUFPO2tCQUFDLENBQWM7Ozs7OztBQUNoQyxDQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vY2xhc3MvLi9zcmMvY29tcG9uZW50cy91bml0cy9jb21tb25zL2xheW91dC9mb290ZXIvaW5kZXgudHN4P2I3YTQiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHN0eWxlZCBmcm9tIFwiQGVtb3Rpb24vc3R5bGVkXCI7XHJcblxyXG5jb25zdCBXcmFwcGVyID0gc3R5bGVkLmRpdmBcclxuICBoZWlnaHQ6IDUwcHg7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogZ3JheTtcclxuYDtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIExheW91dGZvb3RlcigpIHtcclxuICByZXR1cm4gPFdyYXBwZXI+7Jes6riw64qUIO2RuO2EsCDsmIHsl60g7J6F64uI64ukLjwvV3JhcHBlcj47XHJcbn1cclxuIl0sIm5hbWVzIjpbInN0eWxlZCIsIldyYXBwZXIiLCJkaXYiLCJMYXlvdXRmb290ZXIiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./src/components/units/commons/layout/footer/index.tsx\n");

/***/ }),

/***/ "./src/components/units/commons/layout/header/index.tsx":
/*!**************************************************************!*\
  !*** ./src/components/units/commons/layout/header/index.tsx ***!
  \**************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ Layoutheader)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @emotion/styled */ \"@emotion/styled\");\n/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_emotion_styled__WEBPACK_IMPORTED_MODULE_1__);\n\n\nconst Wrapper = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`\n  height: 250px;\n  background-color: skyblue;\n`;\nfunction Layoutheader() {\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Wrapper, {\n        children: \"여기는 해더 영역 입니다.\"\n    }, void 0, false, {\n        fileName: \"C:\\\\Users\\\\코드캠프\\\\Desktop\\\\codecamp fe-06\\\\class\\\\src\\\\components\\\\units\\\\commons\\\\layout\\\\header\\\\index.tsx\",\n        lineNumber: 9,\n        columnNumber: 10\n    }, this));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvY29tcG9uZW50cy91bml0cy9jb21tb25zL2xheW91dC9oZWFkZXIvaW5kZXgudHN4LmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7OztBQUFvQztBQUVwQyxLQUFLLENBQUNDLE9BQU8sR0FBR0QsNERBQVUsQ0FBQzs7O0FBRzNCO0FBRWUsUUFBUSxDQUFDRyxZQUFZLEdBQUcsQ0FBQztJQUN0QyxNQUFNLDZFQUFFRixPQUFPO2tCQUFDLENBQWM7Ozs7OztBQUNoQyxDQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vY2xhc3MvLi9zcmMvY29tcG9uZW50cy91bml0cy9jb21tb25zL2xheW91dC9oZWFkZXIvaW5kZXgudHN4P2ExNDMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHN0eWxlZCBmcm9tIFwiQGVtb3Rpb24vc3R5bGVkXCI7XHJcblxyXG5jb25zdCBXcmFwcGVyID0gc3R5bGVkLmRpdmBcclxuICBoZWlnaHQ6IDI1MHB4O1xyXG4gIGJhY2tncm91bmQtY29sb3I6IHNreWJsdWU7XHJcbmA7XHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBMYXlvdXRoZWFkZXIoKSB7XHJcbiAgcmV0dXJuIDxXcmFwcGVyPuyXrOq4sOuKlCDtlbTrjZQg7JiB7JetIOyeheuLiOuLpC48L1dyYXBwZXI+O1xyXG59XHJcbiJdLCJuYW1lcyI6WyJzdHlsZWQiLCJXcmFwcGVyIiwiZGl2IiwiTGF5b3V0aGVhZGVyIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./src/components/units/commons/layout/header/index.tsx\n");

/***/ }),

/***/ "./src/components/units/commons/layout/index.tsx":
/*!*******************************************************!*\
  !*** ./src/components/units/commons/layout/index.tsx ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ Layout)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _banner__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./banner */ \"./src/components/units/commons/layout/banner/index.tsx\");\n/* harmony import */ var _navigation__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./navigation */ \"./src/components/units/commons/layout/navigation/index.tsx\");\n/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @emotion/styled */ \"@emotion/styled\");\n/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_emotion_styled__WEBPACK_IMPORTED_MODULE_3__);\n/* harmony import */ var _footer__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./footer */ \"./src/components/units/commons/layout/footer/index.tsx\");\n/* harmony import */ var _header__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./header */ \"./src/components/units/commons/layout/header/index.tsx\");\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! next/router */ \"next/router\");\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_6__);\n\n\n\n\n\n\n\nconst Body = (_emotion_styled__WEBPACK_IMPORTED_MODULE_3___default().div)`\n  height: 500px;\n`;\nconst LayoutSidebar = (_emotion_styled__WEBPACK_IMPORTED_MODULE_3___default().div)`\n  width: 450px;\n  height: 500px;\n  background-color: orange;\n`;\nconst HIDDEN_HEADER = [\n    \"/12-05-modal-refactoring\"\n];\nconst BodyWrapper = (_emotion_styled__WEBPACK_IMPORTED_MODULE_3___default().div)`\n  display: flex;\n`;\nfunction Layout(props) {\n    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_6__.useRouter)();\n    console.log(router);\n    const isHidden = HIDDEN_HEADER.includes(router.asPath);\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n        children: [\n            !isHidden && /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_header__WEBPACK_IMPORTED_MODULE_5__[\"default\"], {}, void 0, false, {\n                fileName: \"C:\\\\Users\\\\코드캠프\\\\Desktop\\\\codecamp fe-06\\\\class\\\\src\\\\components\\\\units\\\\commons\\\\layout\\\\index.tsx\",\n                lineNumber: 37,\n                columnNumber: 21\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_banner__WEBPACK_IMPORTED_MODULE_1__[\"default\"], {}, void 0, false, {\n                fileName: \"C:\\\\Users\\\\코드캠프\\\\Desktop\\\\codecamp fe-06\\\\class\\\\src\\\\components\\\\units\\\\commons\\\\layout\\\\index.tsx\",\n                lineNumber: 38,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_navigation__WEBPACK_IMPORTED_MODULE_2__[\"default\"], {}, void 0, false, {\n                fileName: \"C:\\\\Users\\\\코드캠프\\\\Desktop\\\\codecamp fe-06\\\\class\\\\src\\\\components\\\\units\\\\commons\\\\layout\\\\index.tsx\",\n                lineNumber: 39,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(BodyWrapper, {\n                children: [\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(LayoutSidebar, {\n                        children: \"여기는 사이드바 입니다!!!\"\n                    }, void 0, false, {\n                        fileName: \"C:\\\\Users\\\\코드캠프\\\\Desktop\\\\codecamp fe-06\\\\class\\\\src\\\\components\\\\units\\\\commons\\\\layout\\\\index.tsx\",\n                        lineNumber: 41,\n                        columnNumber: 9\n                    }, this),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Body, {\n                        children: [\n                            props.children,\n                            \"바디영역\"\n                        ]\n                    }, void 0, true, {\n                        fileName: \"C:\\\\Users\\\\코드캠프\\\\Desktop\\\\codecamp fe-06\\\\class\\\\src\\\\components\\\\units\\\\commons\\\\layout\\\\index.tsx\",\n                        lineNumber: 42,\n                        columnNumber: 9\n                    }, this)\n                ]\n            }, void 0, true, {\n                fileName: \"C:\\\\Users\\\\코드캠프\\\\Desktop\\\\codecamp fe-06\\\\class\\\\src\\\\components\\\\units\\\\commons\\\\layout\\\\index.tsx\",\n                lineNumber: 40,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_footer__WEBPACK_IMPORTED_MODULE_4__[\"default\"], {}, void 0, false, {\n                fileName: \"C:\\\\Users\\\\코드캠프\\\\Desktop\\\\codecamp fe-06\\\\class\\\\src\\\\components\\\\units\\\\commons\\\\layout\\\\index.tsx\",\n                lineNumber: 44,\n                columnNumber: 7\n            }, this)\n        ]\n    }, void 0, true));\n}; // 특정페이지에선 배너 혹은 네비게이션을 안쓰고 숨시고 싶다 그러면 조건부 랜더링을 하면된다 .\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvY29tcG9uZW50cy91bml0cy9jb21tb25zL2xheW91dC9pbmRleC50c3guanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7O0FBQW1DO0FBQ1E7QUFDUDtBQUNEO0FBRUE7QUFDSTtBQUV2QyxLQUFLLENBQUNNLElBQUksR0FBR0osNERBQVUsQ0FBQzs7QUFFeEI7QUFFQSxLQUFLLENBQUNNLGFBQWEsR0FBR04sNERBQVUsQ0FBQzs7OztBQUlqQztBQUVBLEtBQUssQ0FBQ08sYUFBYSxHQUFHLENBQUM7SUFBQSxDQUEwQjtBQUFBLENBQUM7QUFFbEQsS0FBSyxDQUFDQyxXQUFXLEdBQUdSLDREQUFVLENBQUM7O0FBRS9CO0FBTWUsUUFBUSxDQUFDUyxNQUFNLENBQUNDLEtBQW1CLEVBQUUsQ0FBQztJQUNuRCxLQUFLLENBQUNDLE1BQU0sR0FBR1Isc0RBQVM7SUFDeEJTLE9BQU8sQ0FBQ0MsR0FBRyxDQUFDRixNQUFNO0lBRWxCLEtBQUssQ0FBQ0csUUFBUSxHQUFHUCxhQUFhLENBQUNRLFFBQVEsQ0FBQ0osTUFBTSxDQUFDSyxNQUFNO0lBRXJELE1BQU07O2FBRUFGLFFBQVEsZ0ZBQUtaLCtDQUFZOzs7Ozt3RkFDMUJKLCtDQUFZOzs7Ozt3RkFDWkMsbURBQWdCOzs7Ozt3RkFDaEJTLFdBQVc7O2dHQUNURixhQUFhO2tDQUFDLENBQWU7Ozs7OztnR0FDVEYsSUFBaEI7OzRCQUFFTSxLQUFLLENBQUNPLFFBQVE7NEJBQUMsQ0FBSTs7Ozs7Ozs7Ozs7Ozt3RkFFbkJoQiwrQ0FBSTs7Ozs7OztBQUduQixDQUFDLENBRUQsQ0FBc0QiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9jbGFzcy8uL3NyYy9jb21wb25lbnRzL3VuaXRzL2NvbW1vbnMvbGF5b3V0L2luZGV4LnRzeD9iMmJkIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBMYXlvdXRCYW5uZXIgZnJvbSBcIi4vYmFubmVyXCI7XHJcbmltcG9ydCBMYXlvdXROYXZpZ2F0aW9uIGZyb20gXCIuL25hdmlnYXRpb25cIjtcclxuaW1wb3J0IHN0eWxlZCBmcm9tIFwiQGVtb3Rpb24vc3R5bGVkXCI7XHJcbmltcG9ydCBMYXlvdXRmb290ZXIgZnJvbSBcIi4vZm9vdGVyXCI7XHJcbmltcG9ydCB7IFJlYWN0Tm9kZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgTGF5b3V0aGVhZGVyIGZyb20gXCIuL2hlYWRlclwiO1xyXG5pbXBvcnQgeyB1c2VSb3V0ZXIgfSBmcm9tIFwibmV4dC9yb3V0ZXJcIjtcclxuXHJcbmNvbnN0IEJvZHkgPSBzdHlsZWQuZGl2YFxyXG4gIGhlaWdodDogNTAwcHg7XHJcbmA7XHJcblxyXG5jb25zdCBMYXlvdXRTaWRlYmFyID0gc3R5bGVkLmRpdmBcclxuICB3aWR0aDogNDUwcHg7XHJcbiAgaGVpZ2h0OiA1MDBweDtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiBvcmFuZ2U7XHJcbmA7XHJcblxyXG5jb25zdCBISURERU5fSEVBREVSID0gW1wiLzEyLTA1LW1vZGFsLXJlZmFjdG9yaW5nXCJdO1xyXG5cclxuY29uc3QgQm9keVdyYXBwZXIgPSBzdHlsZWQuZGl2YFxyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbmA7XHJcblxyXG5pbnRlcmZhY2UgSUxheW91dFByb3BzIHtcclxuICBjaGlsZHJlbjogUmVhY3ROb2RlO1xyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBMYXlvdXQocHJvcHM6IElMYXlvdXRQcm9wcykge1xyXG4gIGNvbnN0IHJvdXRlciA9IHVzZVJvdXRlcigpO1xyXG4gIGNvbnNvbGUubG9nKHJvdXRlcik7XHJcblxyXG4gIGNvbnN0IGlzSGlkZGVuID0gSElEREVOX0hFQURFUi5pbmNsdWRlcyhyb3V0ZXIuYXNQYXRoKTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDw+XHJcbiAgICAgIHshaXNIaWRkZW4gJiYgPExheW91dGhlYWRlciAvPn1cclxuICAgICAgPExheW91dEJhbm5lciAvPlxyXG4gICAgICA8TGF5b3V0TmF2aWdhdGlvbiAvPlxyXG4gICAgICA8Qm9keVdyYXBwZXI+XHJcbiAgICAgICAgPExheW91dFNpZGViYXI+7Jes6riw64qUIOyCrOydtOuTnOuwlCDsnoXri4jri6QhISE8L0xheW91dFNpZGViYXI+XHJcbiAgICAgICAgPEJvZHk+e3Byb3BzLmNoaWxkcmVufeuwlOuUlOyYgeyXrTwvQm9keT5cclxuICAgICAgPC9Cb2R5V3JhcHBlcj5cclxuICAgICAgPExheW91dGZvb3RlciAvPlxyXG4gICAgPC8+XHJcbiAgKTtcclxufVxyXG5cclxuLy8g7Yq57KCV7Y6Y7J207KeA7JeQ7ISgIOuwsOuEiCDtmLnsnYAg64Sk67mE6rKM7J207IWY7J2EIOyViOyTsOqzoCDsiKjsi5zqs6Ag7Iu264ukIOq3uOufrOuptCDsobDqsbTrtoAg656c642U66eB7J2EIO2VmOuptOuQnOuLpCAuXHJcbiJdLCJuYW1lcyI6WyJMYXlvdXRCYW5uZXIiLCJMYXlvdXROYXZpZ2F0aW9uIiwic3R5bGVkIiwiTGF5b3V0Zm9vdGVyIiwiTGF5b3V0aGVhZGVyIiwidXNlUm91dGVyIiwiQm9keSIsImRpdiIsIkxheW91dFNpZGViYXIiLCJISURERU5fSEVBREVSIiwiQm9keVdyYXBwZXIiLCJMYXlvdXQiLCJwcm9wcyIsInJvdXRlciIsImNvbnNvbGUiLCJsb2ciLCJpc0hpZGRlbiIsImluY2x1ZGVzIiwiYXNQYXRoIiwiY2hpbGRyZW4iXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./src/components/units/commons/layout/index.tsx\n");

/***/ }),

/***/ "./src/components/units/commons/layout/navigation/index.tsx":
/*!******************************************************************!*\
  !*** ./src/components/units/commons/layout/navigation/index.tsx ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ LayoutNavigation)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @emotion/styled */ \"@emotion/styled\");\n/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_emotion_styled__WEBPACK_IMPORTED_MODULE_1__);\n\n\nconst Wrapper = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`\n  height: 50px;\n  background-color: lightgreen;\n`;\nfunction LayoutNavigation() {\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Wrapper, {\n        children: \"여기는 내비 영역 입니다.\"\n    }, void 0, false, {\n        fileName: \"C:\\\\Users\\\\코드캠프\\\\Desktop\\\\codecamp fe-06\\\\class\\\\src\\\\components\\\\units\\\\commons\\\\layout\\\\navigation\\\\index.tsx\",\n        lineNumber: 9,\n        columnNumber: 10\n    }, this));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvY29tcG9uZW50cy91bml0cy9jb21tb25zL2xheW91dC9uYXZpZ2F0aW9uL2luZGV4LnRzeC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7QUFBb0M7QUFFcEMsS0FBSyxDQUFDQyxPQUFPLEdBQUdELDREQUFVLENBQUM7OztBQUczQjtBQUVlLFFBQVEsQ0FBQ0csZ0JBQWdCLEdBQUcsQ0FBQztJQUMxQyxNQUFNLDZFQUFFRixPQUFPO2tCQUFDLENBQWM7Ozs7OztBQUNoQyxDQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vY2xhc3MvLi9zcmMvY29tcG9uZW50cy91bml0cy9jb21tb25zL2xheW91dC9uYXZpZ2F0aW9uL2luZGV4LnRzeD84M2ZlIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBzdHlsZWQgZnJvbSBcIkBlbW90aW9uL3N0eWxlZFwiO1xyXG5cclxuY29uc3QgV3JhcHBlciA9IHN0eWxlZC5kaXZgXHJcbiAgaGVpZ2h0OiA1MHB4O1xyXG4gIGJhY2tncm91bmQtY29sb3I6IGxpZ2h0Z3JlZW47XHJcbmA7XHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBMYXlvdXROYXZpZ2F0aW9uKCkge1xyXG4gIHJldHVybiA8V3JhcHBlcj7sl6zquLDripQg64K067mEIOyYgeyXrSDsnoXri4jri6QuPC9XcmFwcGVyPjtcclxufVxyXG4iXSwibmFtZXMiOlsic3R5bGVkIiwiV3JhcHBlciIsImRpdiIsIkxheW91dE5hdmlnYXRpb24iXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./src/components/units/commons/layout/navigation/index.tsx\n");

/***/ }),

/***/ "./node_modules/antd/dist/antd.css":
/*!*****************************************!*\
  !*** ./node_modules/antd/dist/antd.css ***!
  \*****************************************/
/***/ (() => {



/***/ }),

/***/ "@apollo/client":
/*!*********************************!*\
  !*** external "@apollo/client" ***!
  \*********************************/
/***/ ((module) => {

"use strict";
module.exports = require("@apollo/client");

/***/ }),

/***/ "@emotion/react":
/*!*********************************!*\
  !*** external "@emotion/react" ***!
  \*********************************/
/***/ ((module) => {

"use strict";
module.exports = require("@emotion/react");

/***/ }),

/***/ "@emotion/styled":
/*!**********************************!*\
  !*** external "@emotion/styled" ***!
  \**********************************/
/***/ ((module) => {

"use strict";
module.exports = require("@emotion/styled");

/***/ }),

/***/ "next/router":
/*!******************************!*\
  !*** external "next/router" ***!
  \******************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-dev-runtime");

/***/ }),

/***/ "apollo-upload-client":
/*!***************************************!*\
  !*** external "apollo-upload-client" ***!
  \***************************************/
/***/ ((module) => {

"use strict";
module.exports = import("apollo-upload-client");;

/***/ }),

/***/ "firebase/app":
/*!*******************************!*\
  !*** external "firebase/app" ***!
  \*******************************/
/***/ ((module) => {

"use strict";
module.exports = import("firebase/app");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/_app.tsx"));
module.exports = __webpack_exports__;

})();