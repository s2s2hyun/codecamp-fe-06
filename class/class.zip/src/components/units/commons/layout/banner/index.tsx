import styled from "@emotion/styled";

const Wrapper = styled.div`
  height: 50px;
  background-color: yellow;
`;

export default function LayoutBanner() {
  return <Wrapper>여기는 배너 영역 입니다jkljl.</Wrapper>;
}
