import styled from "@emotion/styled";

const Wrapper = styled.div`
  height: 250px;
  background-color: skyblue;
`;

export default function Layoutheader() {
  return <Wrapper>여기는 해더 영역 입니다.</Wrapper>;
}
